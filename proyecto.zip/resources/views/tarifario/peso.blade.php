@extends('adminlte::page')
@section('title', 'Pesos')
@section('template_title')
    Paqueteria Postal
@endsection

@section('content')
@livewire('pesos')
@include('footer')
@endsection
