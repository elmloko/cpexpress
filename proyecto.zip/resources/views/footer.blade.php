<footer class="main-footer">
    <div class="float-right d-none d-sm-inline">
        {{ date('Y') }} Agencia Boliviana de Correos ©
        <strong>UNIENVIO</strong> Todos los derechos reservados.
    </div>
    Todos los derechos reservados.<strong>ecaExpress</strong>
    <a href="mailto:mespinozarojas46@gmail.com" class="opacity-75" title="Marco Antonio Espinoza Rojas">Copyright © MAER
        {{ date('Y') }} </a>
</footer>
